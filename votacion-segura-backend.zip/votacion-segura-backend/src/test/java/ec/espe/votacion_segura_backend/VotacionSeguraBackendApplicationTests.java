package ec.espe.votacion_segura_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VotacionSeguraBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
